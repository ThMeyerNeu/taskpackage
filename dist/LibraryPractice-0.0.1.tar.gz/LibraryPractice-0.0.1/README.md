Makefile

    make run

Practices

PyPi:
install link

    https://pypi.org/project/taskpackagelib/